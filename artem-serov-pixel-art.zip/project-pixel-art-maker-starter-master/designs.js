// Declaring a variable for a table
let my_table = document.querySelector("#pixelCanvas");

// Declaring a variable for a submit button
let submitButton = document.querySelector("input[type=submit]");

// Adding eventListener for submit button
submitButton.addEventListener("click", function makeGrid(event) {
    // Preventing from default (refresh) behavior
    event.preventDefault();
    // Erasing the table
    my_table.innerHTML = "";
    // Defining variables for columns and rows
    let rows = document.querySelector("#inputHeight").value;
    let columns = document.querySelector("#inputWidth").value;
    // loop to create a table
    for (r=0; r<rows; r++) {
        let row = my_table.insertRow(r);
        for (c=0; c<columns; c++) {
            let cell = row.insertCell(c);
            // Adding eventListener to color the cells
            cell.addEventListener("click", function coloring(click) {
                let color = document.querySelector("#colorPicker").value;
                click.target.style.backgroundColor = color;
            });
        }
    }
});
